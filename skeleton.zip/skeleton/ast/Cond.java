package ast;

public abstract class Cond extends ASTNode {

    Cond(Location loc) {
        super(loc);
    }
}
 