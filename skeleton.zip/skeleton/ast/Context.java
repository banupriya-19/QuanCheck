package ast;

import interpreter.Interpreter;
import java.util.HashMap;


public class Context {
    
    final HashMap<String, FuncDef> funcMap;
    final HashMap<String, VarDecl> varMap;
    final FuncDef  containingFuncDef;

    Context(HashMap<String, FuncDef> funcMap, HashMap<String, VarDecl> varMap,FuncDef containingFuncDef)
    {
        this.funcMap = funcMap;
        this.varMap = varMap;
        this.containingFuncDef = containingFuncDef;
    }
  
    public static Context newContext()
    {
       return new Context(new HashMap<String, FuncDef>(),new HashMap<String, VarDecl>(), null);
    }
    Context duplicate()
    {
       return new Context(this.funcMap, (HashMap<String, VarDecl>)this.varMap.clone(), this.containingFuncDef);
    }

    Context duplicate(FuncDef containingFuncDef)
    {
       return new Context(this.funcMap, (HashMap<String, VarDecl>)this.varMap.clone(), containingFuncDef);
    }

    static void checkTypes(Type src, Type dest)
    {
        if(dest == Type.INT && src != Type.INT || 
          dest == Type.REF && src != Type.REF)
        {
            Interpreter.fatalError("Incompatible types",Interpreter.EXIT_STATIC_CHECKING_ERROR);
        }
  
    }
}
