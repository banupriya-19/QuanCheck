package ast;

import interpreter.Interpreter;

public class AssignStmt extends Stmt {

    final String varName;
    final Expr expr;

    public AssignStmt(String varName,Expr expr, Location loc) {
        super(loc);
        this.varName= varName;
        this.expr = expr;
    }

    public String getVarName() {
        return varName;
    }

    public Expr getExpr() {
        return expr;
    }

    @Override
    public String toString() {
        return null;
    }

    @Override
    void check(Context c)
    {   expr.check(c);
        if(!c.varMap.containsKey(varName))
        {
            Interpreter.fatalError("Var undefined", Interpreter.EXIT_STATIC_CHECKING_ERROR);
        }
        VarDecl vd = c.varMap.get(varName);
        Context.checkTypes(expr.getStaticType(c), vd.getType());
        if(!vd.isMutable())
        {
            Interpreter.fatalError("Cannot write to immutable var", Interpreter.EXIT_STATIC_CHECKING_ERROR);
     
        }
    }

}
