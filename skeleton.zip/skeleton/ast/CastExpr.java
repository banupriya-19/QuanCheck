package ast;

import interpreter.Interpreter;

public class CastExpr extends Expr {
    
    final Type type;
    final Expr expr;

    public CastExpr(Type type, Expr expr, Location loc) {
        super(loc);
        this.type = type;
        this.expr = expr;
    }

    public Type getType(){
        return type;
    }
    public Expr getExpr() {
        return expr;
    }

    @Override
    public String toString() {
        return null;
    }

    @Override
    Type getStaticType(Context c)
    {
        return type;
    }

    @Override
    void check(Context c)
    {
         expr.check(c);
         if(type == Type.INT && expr.getStaticType(c) == Type.REF ||
           type == Type.REF && expr.getStaticType(c) == Type.INT) 
         {
            Interpreter.fatalError("Cast", Interpreter.EXIT_STATIC_CHECKING_ERROR);
         }
    }
}
 