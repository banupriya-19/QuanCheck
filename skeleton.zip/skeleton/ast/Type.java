package ast;

public enum Type {

    INT,
    REF,
    Q

}
