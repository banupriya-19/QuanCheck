package ast;

public abstract class Stmt extends ASTNode {

    Stmt(Location loc) {
        super(loc);
    }
}
