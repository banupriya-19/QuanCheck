package ast;

import interpreter.Interpreter;
import java.io.PrintStream;


public class Program extends ASTNode {

    final FuncDefList funcs;


    public Program(FuncDefList funcs, Location loc) {
        super(loc);
        this.funcs=funcs;

    }

    public FuncDefList getFuncs() {
        return funcs;
    }

    public void println(PrintStream ps) {
        //ps.println(expr);
    }
 
    @Override
    public void check(Context c)
    {
        FuncDefList curList = funcs;
        while(curList != null)
        {
            FuncDef funcDef = curList.first;
           
            if(c.funcMap.containsKey(funcDef.varDecl.getName()) || 
            CallExpr.getBuiltInFunc(funcDef.getVarDecl().getName()) != null)
            {
               Interpreter.fatalError("Duplicate function", Interpreter.EXIT_STATIC_CHECKING_ERROR);
            }
            c.funcMap.put(funcDef.varDecl.getName(), funcDef);
            curList = curList.getRest();
        }
        FuncDef funcDef= c.funcMap.get("main");
        if( !(funcDef != null && 
        funcDef.params.first.type == Type.INT &&
        funcDef.params.rest == null) )
        {
            Interpreter.fatalError("main", Interpreter.EXIT_STATIC_CHECKING_ERROR);
        }
        // Check all function definition
        funcs.check(c);
    }

}
