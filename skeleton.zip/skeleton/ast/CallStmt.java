package ast;

import interpreter.Interpreter;

public class CallStmt extends Stmt{
    
    final CallExpr callExpr;

    public CallStmt(String funcName, ExprList args,Location loc)
    {
       super(loc);
       this.callExpr= new CallExpr(funcName, args, loc);
    }

    public CallExpr getcallExpr()
    {
        return callExpr;
    }
    @Override
    public String toString() {
        return null;
    }

    @Override
    void check(Context c)
    {
        callExpr.check(c);
        FuncDef callee = c.funcMap.get(callExpr.getFuncName());
        if(callee == null)
        {
            callee = callExpr.getBuiltInFunc(callExpr.getFuncName());
        }
        if(!callee.varDecl.isMutable())
        {
            Interpreter.fatalError("Cannot call mutable fucntion", Interpreter.EXIT_STATIC_CHECKING_ERROR);
        }
    }
}
