package ast;

public class NilExpr extends Expr {

    
    public NilExpr(Location loc) {
        super(loc);
    }
    @Override
    public String toString() {
        return null;
    }

    @Override
    Type getStaticType(Context c)
    {
        return Type.REF;
    }

    @Override
    void check(Context c)
    {

    }
}
