package ast;

import interpreter.Interpreter;

public class UnaryMinusExpr extends Expr {

    final Expr expr;

    public UnaryMinusExpr(Expr expr, Location loc) {
        super(loc);
        this.expr = expr;
    }

    public Expr getExpr() {
        return expr;
    }

    @Override
    public String toString() {
        return null;
    }

    @Override
    Type getStaticType(Context c)
    {
        return Type.INT;
    }

    @Override
    void check(Context c)
    {
        expr.check(c);
        if(expr.getStaticType(c) != Type.INT)
        {
            Interpreter.fatalError("unary minus", Interpreter.EXIT_STATIC_CHECKING_ERROR);
        }
    }
}
 