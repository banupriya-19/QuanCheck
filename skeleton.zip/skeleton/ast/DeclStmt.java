package ast;

import interpreter.Interpreter;

public class DeclStmt extends Stmt {

    final VarDecl varDecl;
    final Expr expr;

    public DeclStmt(VarDecl varDecl,Expr expr, Location loc) {
        super(loc);
        this.varDecl= varDecl;
        this.expr = expr;
    }

    public VarDecl getVarDecl() {
        return varDecl;
    }

    public Expr getExpr() {
        return expr;
    }

    @Override
    public String toString() {
        return null;
    }

    @Override
    void check(Context c)
    {
        expr.check(c);
        Context.checkTypes(expr.getStaticType(c), varDecl.getType()); 
        if(c.varMap.containsKey(varDecl.getName()))
        {
           Interpreter.fatalError("duplicate var", Interpreter.EXIT_STATIC_CHECKING_ERROR);
        }
        c.varMap.put(varDecl.getName(), varDecl);
    }
}