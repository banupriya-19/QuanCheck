package ast;

import interpreter.Interpreter;

public class IdentExpr extends Expr {

    final String varName;

    public IdentExpr(String varName, Location loc) {
        super(loc);
        this.varName = varName;
    }

    public Object getVarName() {
        return varName;
    }

    @Override
    public String toString() {
        return null;
    }

    @Override
    Type getStaticType(Context c)
    {
      return c.varMap.get(varName).getType();
        }

    @Override
    void check(Context c)
    {
       if(!c.varMap.containsKey(varName))
       {
        Interpreter.fatalError("Undeclared var",Interpreter.EXIT_STATIC_CHECKING_ERROR);
       }
    }
}
