package ast;

import interpreter.Interpreter;

public class CompCond extends Cond {

    public static final int GE = 1;
    public static final int GT = 2;
    public static final int LE = 3;
    public static final int LT = 4;
    public static final int NE = 5;
    public static final int EQ = 6;

    final Expr expr1;
    final int operator;
    final Expr expr2;

    public CompCond(Expr expr1, int operator, Expr expr2, Location loc) {
        super(loc);
        this.expr1 = expr1;
        this.operator = operator;
        this.expr2 = expr2;
    }

    public Expr getLeftExpr() {
        return expr1;
    }

    public int getOperator() {
        return operator;
    }
    
    public Expr getRightExpr() {
        return expr2;
    }

    @Override
    public String toString() {
        return null;
       }

   
       @Override
       void check(Context c)
       {
           expr1.check(c);
           expr2.check(c);
           
            if(expr1.getStaticType(c) != Type.INT || 
                expr2.getStaticType(c) != Type.INT)
                {
                   Interpreter.fatalError(" binary expr Type mismatch", Interpreter.EXIT_STATIC_CHECKING_ERROR);
                }
       }
}
