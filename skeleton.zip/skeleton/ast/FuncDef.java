package ast;

import interpreter.Interpreter;

public class FuncDef extends ASTNode {

    final VarDecl varDecl;
    final FormalDeclList params;
    final StmtList body;

    public FuncDef(VarDecl varDecl, FormalDeclList params , StmtList body, Location loc) {
        super(loc);
        this.varDecl = varDecl;
        this.params = params;
        this.body= body;
    }

    public VarDecl getVarDecl() {
        return varDecl;
    }

    public FormalDeclList getParams() {
        return params;
    }

    public StmtList getBody() {
        return body;
    }
    @Override
    public String toString() {
        return null;
    }

    @Override
    void check(Context c)
    {
        if(params != null){
            params.check(c);
        }
       
        StmtList currStmtList = body;
        while(currStmtList != null && currStmtList.rest!= null)
        {
             currStmtList= currStmtList.rest;
        }
        if(currStmtList == null || !(currStmtList.getFirst() instanceof ReturnStmt))
        {
            Interpreter.fatalError("missing return stmt",Interpreter.EXIT_STATIC_CHECKING_ERROR);
        }
        body.check(c);
    }
}