package interpreter;

abstract class QVal {
    
}
